package pt.iade.hellocar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarTrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarTrackApplication.class, args);
	}

}
